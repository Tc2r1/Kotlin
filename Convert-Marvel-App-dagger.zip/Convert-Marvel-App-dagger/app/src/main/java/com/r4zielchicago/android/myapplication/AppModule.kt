package com.r4zielchicago.android.myapplication

import android.content.Context
import com.r4zielchicago.android.myapplication.api.MarvelApi
import com.r4zielchicago.android.myapplication.network.NetworkService
import com.r4zielchicago.android.myapplication.repository.DetailsRepository
import com.r4zielchicago.android.myapplication.repository.HeroRepository
import com.r4zielchicago.android.myapplication.utilities.SharedPrefsUtil
import com.r4zielchicago.android.myapplication.utilities.SharedPrefsUtilImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
class AppModule {

    @Provides
    fun providesSharedPrefsUtil(@ApplicationContext context: Context) : SharedPrefsUtil {
        return SharedPrefsUtilImpl(context)
    }

    @Provides
    fun providesMarvelApi(networkService: NetworkService) : MarvelApi {
        return networkService.getRetrofitInstance().create(MarvelApi::class.java)
    }
}