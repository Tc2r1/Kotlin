package com.r4zielchicago.android.myapplication.ui.hero

import com.r4zielchicago.android.myapplication.repository.DetailsRepository
import com.r4zielchicago.android.myapplication.repository.HeroRepository
import com.r4zielchicago.android.myapplication.ui.details.viewModel.DetailsViewModel
import com.r4zielchicago.android.myapplication.ui.details.viewModel.Factory
import com.r4zielchicago.android.myapplication.utilities.SharedPrefsUtil

class HeroViewModelFactory(
    private val heroRepository: HeroRepository,
    private val prefsUtil: SharedPrefsUtil) : Factory<HeroViewModel>
{
    override fun create(): HeroViewModel {
        return HeroViewModel(heroRepository, prefsUtil)
    }

}