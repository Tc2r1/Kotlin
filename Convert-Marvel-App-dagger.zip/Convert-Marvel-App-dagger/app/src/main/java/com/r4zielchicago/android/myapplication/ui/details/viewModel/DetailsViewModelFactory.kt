package com.r4zielchicago.android.myapplication.ui.details.viewModel

import com.r4zielchicago.android.myapplication.repository.DetailsRepository
import com.r4zielchicago.android.myapplication.repository.HeroRepository
import com.r4zielchicago.android.myapplication.utilities.SharedPrefsUtil

class DetailsViewModelFactory(
    private val detailsRepository: DetailsRepository,
    private val heroRepository: HeroRepository,
    private val prefsUtil: SharedPrefsUtil) : Factory<DetailsViewModel>
{
    override fun create(): DetailsViewModel {
        return DetailsViewModel(detailsRepository, heroRepository, prefsUtil)
    }

}