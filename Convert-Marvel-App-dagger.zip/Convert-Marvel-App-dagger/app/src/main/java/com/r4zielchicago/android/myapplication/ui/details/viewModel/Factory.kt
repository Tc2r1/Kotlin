package com.r4zielchicago.android.myapplication.ui.details.viewModel

interface Factory<T> {
    fun create(): T
}